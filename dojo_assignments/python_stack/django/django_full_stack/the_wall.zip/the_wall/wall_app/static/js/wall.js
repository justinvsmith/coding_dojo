// $("document").ready(function(){    
//     $("p.message").hover(
//         function(){
//             $(".new_comment").show();
//     },  function(){
//             $(".new_comment").hide();
// });

// });
